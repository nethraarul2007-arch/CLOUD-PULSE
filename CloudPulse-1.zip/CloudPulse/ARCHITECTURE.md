# CloudPulse Architecture

## Architecture diagram

```text
┌───────────────────────────────────────────────────────┐
│                     User / Browser                    │
│  HTML dashboard · CSS layout · JavaScript · Canvas    │
└───────────────────────────┬───────────────────────────┘
                            │ HTTP requests / JSON
                            ▼
┌───────────────────────────────────────────────────────┐
│                  Node.js HTTP Server                  │
│                   server.js (built-in)                │
│                                                       │
│  ┌────────────────┐ ┌────────────────┐ ┌───────────┐ │
│  │ Health endpoint│ │ Metrics endpoint│ │ Logs API  │ │
│  │  /api/health   │ │ /api/metrics    │ │ POST logs │ │
│  └────────────────┘ └───────┬────────┘ └─────┬─────┘ │
│                             │                │       │
│                   ┌─────────▼────────────────▼────┐  │
│                   │ Demo metrics + in-memory logs │  │
│                   │ thresholds + service examples │  │
│                   └───────────────────────────────┘  │
└───────────────────────────────────────────────────────┘
                            │
                            ▼
             JSON responses polled every 5 seconds
                            │
                            ▼
          Dashboard cards · trend chart · alerts · logs
```

## Request flow

1. The browser loads `/`, `/styles.css`, and `/app.js`.
2. Browser JavaScript requests `GET /api/metrics`.
3. The server creates a snapshot containing clearly marked simulated resource metrics, example service health, thresholds, active alerts, and recent in-memory logs.
4. The browser updates metric cards, draws the CPU/memory trend chart, and renders alerts, services, and logs.
5. A user can add a sample log through `POST /api/logs`; the server validates and limits the input, then returns the created event.
6. The browser polls again every five seconds.

## Technology choices

- **HTML:** semantic dashboard structure.
- **CSS:** responsive grid, cards, status colors, and mobile layout.
- **Browser JavaScript:** fetch API, rendering, polling, and Canvas chart.
- **Node.js built-ins:** `http` for server/API, `fs` and `path` for static assets, and `os` for local host context.
- **In-memory arrays:** temporary demo logs and sample service definitions; data resets when the server restarts.

## Data-flow note

Resource percentages and sample service statuses are generated demo data, not readings from a real cloud environment. The `os` module is used only for contextual local host information.
