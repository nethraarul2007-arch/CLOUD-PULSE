const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const PORT = Number(process.env.PORT) || 3000;
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const startedAt = Date.now();

const services = [
  { id: 'api-gateway', name: 'API Gateway', region: 'ap-south-1', status: 'healthy', latency: 42 },
  { id: 'auth-service', name: 'Auth Service', region: 'ap-south-1', status: 'healthy', latency: 68 },
  { id: 'worker-queue', name: 'Worker Queue', region: 'ap-south-1', status: 'degraded', latency: 184 },
  { id: 'database', name: 'Database', region: 'ap-south-1', status: 'healthy', latency: 31 }
];
const logs = [];
function addLog(level, service, message) {
  logs.unshift({ id: `${Date.now()}-${Math.random().toString(16).slice(2, 7)}`, time: new Date().toISOString(), level, service, message });
  if (logs.length > 60) logs.pop();
}
addLog('INFO', 'system', 'CloudPulse monitoring service initialized');
addLog('WARN', 'worker-queue', 'Queue processing latency is elevated (simulated event)');
addLog('INFO', 'api-gateway', 'Health check passed');

function metricSnapshot() {
  // DEMO ONLY: these values are generated for dashboard demonstration.
  const cpu = Math.min(98, Math.max(8, Math.round(42 + Math.sin(Date.now() / 17000) * 18 + (Math.random() * 12 - 6))));
  const memory = Math.min(96, Math.max(25, Math.round(61 + Math.sin(Date.now() / 25000) * 9 + (Math.random() * 6 - 3))));
  const disk = Math.min(95, Math.max(20, Math.round(48 + Math.sin(Date.now() / 40000) * 5)));
  const uptimeSeconds = Math.floor((Date.now() - startedAt) / 1000);
  const cpuThreshold = 80, memoryThreshold = 85;
  const alerts = [];
  if (cpu >= cpuThreshold) alerts.push({ id: 'cpu-high', severity: 'critical', title: 'High CPU usage', detail: `CPU usage is ${cpu}% (threshold ${cpuThreshold}%)` });
  if (memory >= memoryThreshold) alerts.push({ id: 'memory-high', severity: 'warning', title: 'High memory usage', detail: `Memory usage is ${memory}% (threshold ${memoryThreshold}%)` });
  if (services.some(s => s.status === 'degraded')) alerts.push({ id: 'service-degraded', severity: 'warning', title: 'Service degraded', detail: 'Worker Queue latency is above its normal range' });
  return {
    timestamp: new Date().toISOString(),
    simulated: true,
    metrics: { cpu, memory, disk, uptimeSeconds, host: os.hostname(), platform: os.platform(), cpuCores: os.cpus().length },
    thresholds: { cpu: cpuThreshold, memory: memoryThreshold },
    services: services.map(s => ({ ...s, checkedAt: new Date().toISOString() })),
    alerts,
    logs: logs.slice(0, 12)
  };
}

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml' };
function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(body);
}
const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && url.pathname === '/api/health') {
    return send(res, 200, JSON.stringify({ ok: true, service: 'CloudPulse', simulated: true, timestamp: new Date().toISOString() }));
  }
  if (req.method === 'GET' && url.pathname === '/api/metrics') {
    return send(res, 200, JSON.stringify(metricSnapshot()));
  }
  if (req.method === 'POST' && url.pathname === '/api/logs') {
    let body = '';
    req.on('data', chunk => { body += chunk; if (body.length > 5000) req.destroy(); });
    req.on('end', () => {
      try {
        const data = JSON.parse(body || '{}');
        const level = ['INFO', 'WARN', 'ERROR'].includes(data.level) ? data.level : 'INFO';
        const service = String(data.service || 'dashboard').slice(0, 40);
        const message = String(data.message || 'Manual demo log entry').slice(0, 180);
        addLog(level, service, message);
        send(res, 201, JSON.stringify({ ok: true, log: logs[0] }));
      } catch {
        send(res, 400, JSON.stringify({ ok: false, error: 'Invalid JSON payload' }));
      }
    });
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, JSON.stringify({ error: 'Method not allowed' }));
  let pathname = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  const target = path.resolve(PUBLIC, '.' + pathname);
  if (!target.startsWith(PUBLIC + path.sep) || !fs.existsSync(target) || !fs.statSync(target).isFile()) {
    return send(res, 404, JSON.stringify({ error: 'Not found' }));
  }
  const type = MIME[path.extname(target)] || 'application/octet-stream';
  res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(target).pipe(res);
});
server.listen(PORT, () => console.log(`CloudPulse is running at http://localhost:${PORT}`));
process.on('SIGINT', () => { console.log('\nShutting down CloudPulse...'); server.close(() => process.exit(0)); });
