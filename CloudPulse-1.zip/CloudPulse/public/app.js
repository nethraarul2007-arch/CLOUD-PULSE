const $ = (id) => document.getElementById(id);
const samples = [];
const maxSamples = 12;
let lastSnapshot = null;

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function formatTime(iso) {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}
function setMetric(name, value) {
  $(`${name}-value`).textContent = value;
  $(`${name}-meter`).style.width = `${value}%`;
}
function drawChart() {
  const canvas = $('usage-chart');
  const rect = canvas.getBoundingClientRect();
  const ratio = window.devicePixelRatio || 1;
  canvas.width = Math.max(1, Math.floor(rect.width * ratio));
  canvas.height = Math.max(1, Math.floor(rect.height * ratio));
  const ctx = canvas.getContext('2d');
  ctx.scale(ratio, ratio);
  const w = rect.width, h = rect.height;
  const pad = { left: 28, right: 10, top: 12, bottom: 25 };
  const cw = w - pad.left - pad.right, ch = h - pad.top - pad.bottom;
  ctx.clearRect(0, 0, w, h);
  ctx.font = '10px DM Sans, sans-serif';
  ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
  [0, 25, 50, 75, 100].forEach(v => {
    const y = pad.top + ch * (1 - v / 100);
    ctx.strokeStyle = '#253249'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(w - pad.right, y); ctx.stroke();
    ctx.fillStyle = '#71839d'; ctx.fillText(String(v), pad.left - 8, y);
  });
  const series = [
    { key: 'cpu', color: '#a18aff' },
    { key: 'memory', color: '#59b7ff' }
  ];
  series.forEach(s => {
    if (!samples.length) return;
    ctx.strokeStyle = s.color; ctx.lineWidth = 2.3; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.beginPath();
    samples.forEach((p, i) => {
      const x = pad.left + (samples.length === 1 ? cw / 2 : (i / (maxSamples - 1)) * cw);
      const y = pad.top + ch * (1 - p[s.key] / 100);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.stroke();
    const last = samples[samples.length - 1];
    const x = pad.left + (samples.length === 1 ? cw / 2 : ((samples.length - 1) / (maxSamples - 1)) * cw);
    const y = pad.top + ch * (1 - last[s.key] / 100);
    ctx.fillStyle = s.color; ctx.beginPath(); ctx.arc(x, y, 3.5, 0, Math.PI * 2); ctx.fill();
  });
  ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillStyle = '#71839d';
  samples.forEach((p, i) => {
    if (i % 3 !== 0 && i !== samples.length - 1) return;
    const x = pad.left + (samples.length === 1 ? cw / 2 : (i / (maxSamples - 1)) * cw);
    ctx.fillText(p.time, x, h - 17);
  });
}
function renderAlerts(alerts) {
  $('alert-total').textContent = alerts.length;
  $('nav-alert-count').textContent = alerts.length;
  if (!alerts.length) {
    $('alert-list').innerHTML = '<div class="empty-state">✓ No active threshold alerts</div>';
    return;
  }
  $('alert-list').innerHTML = alerts.map(a => `<div class="alert-item ${a.severity === 'warning' ? 'warning' : ''}"><div class="alert-symbol">${a.severity === 'critical' ? '!' : '△'}</div><div><b>${escapeHtml(a.title)}</b><p>${escapeHtml(a.detail)}</p><small>${escapeHtml(a.severity.toUpperCase())} · just now</small></div></div>`).join('');
}
function renderServices(services) {
  const healthy = services.filter(s => s.status === 'healthy').length;
  $('healthy-value').textContent = healthy;
  $('health-status').textContent = healthy === services.length ? 'All healthy' : 'Attention';
  $('health-status').style.color = healthy === services.length ? 'var(--green)' : 'var(--orange)';
  $('health-status').style.background = healthy === services.length ? '#193a35' : '#493a2b';
  $('service-rows').innerHTML = services.map(s => {
    const degraded = s.status !== 'healthy';
    return `<tr><td><span class="service-name"><i class="service-dot ${degraded ? 'degraded' : ''}"></i>${escapeHtml(s.name)}</span></td><td>${escapeHtml(s.region)}</td><td><span class="service-status ${degraded ? 'degraded' : ''}">${degraded ? '● Degraded' : '● Healthy'}</span></td><td>${Number(s.latency)} ms</td><td>${formatTime(s.checkedAt)}</td></tr>`;
  }).join('');
}
function renderLogs(logs) {
  if (!logs.length) { $('log-list').innerHTML = '<div class="empty-state">No events recorded yet.</div>'; return; }
  $('log-list').innerHTML = logs.slice(0, 8).map(log => `<div class="log-row"><span class="log-time">${formatTime(log.time)}</span><span class="log-level ${escapeHtml(log.level)}">${escapeHtml(log.level)}</span><span class="log-service">${escapeHtml(log.service)}</span><span class="log-message">${escapeHtml(log.message)}</span></div>`).join('');
}
async function refresh() {
  $('refresh-btn').disabled = true;
  $('refresh-btn').textContent = '↻ Refreshing';
  try {
    const response = await fetch('/api/metrics', { cache: 'no-store' });
    if (!response.ok) throw new Error(`Server returned ${response.status}`);
    const data = await response.json();
    lastSnapshot = data;
    setMetric('cpu', data.metrics.cpu);
    setMetric('memory', data.metrics.memory);
    setMetric('disk', data.metrics.disk);
    $('cpu-caption').textContent = data.metrics.cpu >= data.thresholds.cpu ? 'Above threshold' : 'Below 80% threshold';
    $('memory-caption').textContent = data.metrics.memory >= data.thresholds.memory ? 'Above threshold' : 'Below 85% threshold';
    const sample = { cpu: data.metrics.cpu, memory: data.metrics.memory, time: formatTime(data.timestamp) };
    samples.push(sample); if (samples.length > maxSamples) samples.shift();
    drawChart(); renderAlerts(data.alerts); renderServices(data.services); renderLogs(data.logs);
    $('last-updated').textContent = `Updated ${formatTime(data.timestamp)}`;
    $('notice').textContent = 'Demo mode: CPU, memory, disk and service telemetry are simulated. Hostname/platform details are read locally by Node.js; no cloud provider is connected.';
  } catch (error) {
    $('notice').textContent = `Unable to load dashboard data: ${error.message}. Check that the Node.js server is running.`;
  } finally {
    $('refresh-btn').disabled = false;
    $('refresh-btn').textContent = '↻ Refresh';
  }
}
async function addDemoLog() {
  const levels = ['INFO', 'WARN', 'ERROR'];
  const level = levels[Math.floor(Math.random() * levels.length)];
  const messages = {
    INFO: 'Manual demo event: scheduled task completed',
    WARN: 'Manual demo event: response time approaching warning limit',
    ERROR: 'Manual demo event: example request failed with status 500'
  };
  try {
    const response = await fetch('/api/logs', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ level, service: 'dashboard-demo', message: messages[level] })
    });
    if (!response.ok) throw new Error('Could not add event');
    await refresh();
  } catch (error) {
    $('notice').textContent = `Could not add demo event: ${error.message}`;
  }
}
$('refresh-btn').addEventListener('click', refresh);
$('add-log-btn').addEventListener('click', addDemoLog);
window.addEventListener('resize', () => { if (lastSnapshot) drawChart(); });
refresh();
setInterval(refresh, 5000);
