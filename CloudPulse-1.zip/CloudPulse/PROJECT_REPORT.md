# Project Report: CloudPulse — Cloud Resource Monitoring and Alert System

## 1. Abstract

CloudPulse is a lightweight web-based dashboard that demonstrates the concepts of cloud resource monitoring and alert management. It presents CPU, memory, and disk utilization cards, a resource trend chart, service health checks, active alerts, and recent event logs. The frontend uses HTML, CSS, and JavaScript, while a Node.js server built from native modules provides JSON endpoints and serves static files. The current implementation uses simulated resource metrics and example service states to provide a safe, self-contained academic demonstration without requiring a cloud account or external package installation.

## 2. Problem statement

Cloud-hosted applications need a clear way to review resource utilization, service availability, and operational events. Raw telemetry can be difficult to interpret quickly. A dashboard can bring key indicators into one interface and notify an operator when configured values cross defined thresholds.

## 3. Objectives

- Build a responsive monitoring dashboard.
- Display CPU, memory, and disk utilization indicators.
- Visualize CPU and memory samples over time.
- Present health-check results for example services.
- Generate alerts when configured thresholds are crossed.
- Record and display recent event logs.
- Implement a lightweight backend using Node.js built-in modules.
- Document setup, architecture, testing, and limitations.

## 4. Scope

The project demonstrates monitoring-interface and API concepts. It is not connected to an actual cloud provider. Resource percentages, service statuses, latency values, and some events are simulated. Local hostname, operating system platform, and CPU core count are read through Node.js's `os` module only for contextual display/API data.

## 5. Tools and technologies

| Technology | Purpose |
|---|---|
| HTML5 | Page structure |
| CSS3 | Styling and responsive layout |
| JavaScript | UI updates, polling, chart drawing, and interactions |
| Node.js `http` | HTTP server and API endpoints |
| Node.js `fs` and `path` | Serving static files safely |
| Node.js `os` | Local machine context |
| Browser Canvas API | CPU and memory line chart |
| VS Code | Development environment |

## 6. System modules

### 6.1 Dashboard module
Shows resource cards, a trend chart, service table, alert panel, and recent event logs.

### 6.2 Metrics module
The `/api/metrics` endpoint returns a timestamped JSON snapshot. The CPU, memory, and disk values are simulated and labelled as such.

### 6.3 Health-check module
The `/api/health` endpoint reports whether the local CloudPulse HTTP service is responding. The service table contains illustrative service-health records rather than real remote probes.

### 6.4 Alert module
The server compares demo CPU usage against 80% and memory usage against 85%. A degraded-service example can also produce an alert. These rules demonstrate threshold logic.

### 6.5 Event-log module
The server stores recent logs in memory. `POST /api/logs` accepts an INFO, WARN, or ERROR level and bounded service/message strings. The browser safely escapes values before inserting them into the page.

## 7. Methodology

1. Create the Node.js HTTP server using native modules.
2. Add JSON routes for health, metrics, and log creation.
3. Generate a timestamped simulated metrics snapshot.
4. Build the dashboard with semantic HTML and responsive CSS.
5. Use JavaScript `fetch()` to poll the metrics endpoint every five seconds.
6. Draw CPU and memory trends using Canvas.
7. Render threshold alerts, service status, and logs.
8. Validate syntax and test endpoints and user interactions.

## 8. Testing plan and expected results

| Test | Action | Expected result |
|---|---|---|
| Server startup | Run `npm start` | Server listens on port 3000 |
| Health endpoint | GET `/api/health` | JSON response with `ok: true` |
| Metrics endpoint | GET `/api/metrics` | Metrics, thresholds, services, alerts, and logs are returned |
| Dashboard load | Open `http://localhost:3000` | Dashboard components populate |
| Refresh | Click Refresh | New simulated sample is fetched |
| Add event | Click Add demo event | New event appears in recent logs |
| Responsive layout | Resize browser | Layout adapts to smaller screens |
| Syntax check | Run `npm run check` | Node.js syntax check completes without errors |

## 9. Security and reliability considerations

- No third-party server packages are required.
- User-provided log values are length-limited and restricted to recognized log levels.
- The frontend escapes displayed text to reduce HTML injection risk.
- Static file paths are resolved and checked to remain within the public directory.
- The log store is in-memory and resets on restart.
- The current demo is intended for local educational use; production deployment requires authentication, authorization, real telemetry integrations, persistent storage, rate limiting, robust input validation, secure configuration, and monitored alert delivery.

## 10. Limitations

- Metrics and service states are simulated.
- No cloud-provider credentials or APIs are integrated.
- Alerts are visible in the dashboard only; no email, SMS, or push notification is sent.
- Event logs are not persisted to a database.
- The service table represents sample services and does not make external network health checks.

## 11. Future enhancements

- Integrate cloud provider metrics APIs or a real host monitoring agent.
- Store metrics and events in a database.
- Allow users to configure thresholds.
- Add authentication, roles, and audit trails.
- Send notifications using a configured alerting service.
- Add historical filters, export, and deployment health checks.

## 12. Conclusion

CloudPulse demonstrates the core structure of a monitoring dashboard and a lightweight JSON backend. It combines resource cards, a trend chart, service status, threshold alerts, and event logs in one responsive interface. Its self-contained simulated data makes it straightforward to run and present as a student project. The simulation boundary is explicit so that example values are not mistaken for live cloud telemetry.

## 13. Viva questions and answers

**Q1. What is CloudPulse?**  
CloudPulse is a web dashboard that demonstrates cloud resource monitoring and threshold-based alerting.

**Q2. Which technologies are used?**  
HTML, CSS, browser JavaScript, Node.js built-in modules, and the Canvas API.

**Q3. Why is Node.js used?**  
Node.js provides a JavaScript runtime and built-in modules for creating the HTTP server and JSON API without external server packages.

**Q4. What is an API endpoint?**  
An API endpoint is a URL and method through which a client accesses a particular server function or data.

**Q5. What is the purpose of `/api/health`?**  
It reports whether the CloudPulse server's health route is responding.

**Q6. How are alerts generated?**  
The server compares simulated CPU and memory values with configured thresholds and adds alert objects when a threshold is crossed.

**Q7. What are the configured CPU and memory thresholds?**  
CPU usage at or above 80%, and memory usage at or above 85%.

**Q8. Are the displayed metrics real?**  
No. Resource percentages, service status, and latency values are simulated for demonstration. The application is not connected to a cloud provider.

**Q9. What is polling?**  
Polling means requesting updated data repeatedly at a fixed interval. This dashboard polls every five seconds.

**Q10. How is the chart created?**  
The frontend uses the HTML Canvas API to draw grid lines and CPU/memory trend lines from recent samples.

**Q11. Where are event logs stored?**  
In a server-side in-memory array. They are lost when the server restarts.

**Q12. What does HTTP status code 404 mean?**  
It means the requested route or resource was not found.

**Q13. Why should user input be escaped?**  
Escaping helps prevent input from being interpreted as HTML or script when displayed in the browser.

**Q14. How could this project be made production-ready?**  
Connect real telemetry sources, add authentication and authorization, persist data, configure notification channels, and add monitoring and deployment security.

**Q15. What is the difference between monitoring and alerting?**  
Monitoring collects and displays system state; alerting evaluates conditions and notifies users when defined rules are met.
