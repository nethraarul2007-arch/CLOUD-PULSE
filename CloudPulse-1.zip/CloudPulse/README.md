# CloudPulse: Cloud Resource Monitoring and Alert System

CloudPulse is a student-friendly monitoring dashboard built with **HTML, CSS, browser JavaScript, and Node.js built-in modules only**. It demonstrates service health checks, resource utilization charts, event logs, and threshold-based alerts.

> **Important — simulated data:** CPU, memory, disk percentages, service statuses, service latencies, and generated alert examples are simulated demo values. The application is not connected to AWS, Azure, Google Cloud, or real server telemetry. Node.js reads limited local host information (hostname, platform, CPU core count) for context only.

## Features

- Responsive dark dashboard for desktop and mobile.
- CPU, memory, and disk usage cards.
- Canvas-based CPU and memory trend chart, refreshed every 5 seconds.
- Four example service-health rows with latency and status.
- Threshold alerts: CPU at **80% or higher**, memory at **85% or higher**, plus an example degraded-service alert.
- Recent event log with INFO, WARN, and ERROR levels.
- “Add demo event” button to append an event through the Node API.
- Accessible labels, keyboard focus styles, escaped log content, and no third-party runtime dependencies.

## Requirements

- Node.js 18 or newer (Node.js 20 LTS or newer recommended).
- VS Code (recommended editor).
- A modern browser.

No `npm install` is needed because the project uses only Node.js built-in modules.

## Folder structure

```text
CloudPulse/
├── public/
│   ├── index.html       # Dashboard layout
│   ├── styles.css       # Responsive styling
│   └── app.js           # Charts, polling, rendering, and interactions
├── server.js            # Node.js HTTP server and demo API
├── package.json         # Project metadata and commands
├── README.md            # Setup and documentation
├── PROJECT_REPORT.md    # Academic project report
└── ARCHITECTURE.md      # Architecture diagram and request flow
```

## Run in VS Code

1. Download and extract `CloudPulse.zip`.
2. Open VS Code → **File → Open Folder** → choose the extracted `CloudPulse` folder.
3. Confirm Node.js is installed in the VS Code terminal:

   ```bash
   node --version
   ```

4. Start the server:

   ```bash
   npm start
   ```

   Or run directly:

   ```bash
   node server.js
   ```

5. Open **http://localhost:3000** in your browser.
6. Use **Refresh** to request the latest sample and **Add demo event** to test the event-log API.
7. Stop the server with **Ctrl+C** in the terminal.

If port 3000 is busy, choose another port:
- Windows PowerShell: `$env:PORT=3001; node server.js`
- macOS/Linux: `PORT=3001 node server.js`

Then open `http://localhost:3001`.

## API endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Basic server health response |
| GET | `/api/metrics` | Simulated metrics, thresholds, services, alerts, and recent logs |
| POST | `/api/logs` | Add a demo event as JSON |

Example:

```bash
curl http://localhost:3000/api/health
curl http://localhost:3000/api/metrics
curl -X POST http://localhost:3000/api/logs \
  -H "Content-Type: application/json" \
  -d "{\"level\":\"WARN\",\"service\":\"demo\",\"message\":\"Sample warning\"}"
```

## Testing checklist

1. Run `npm run check` to validate Node.js syntax.
2. Open `/api/health`; expect JSON containing `"ok": true` and `"simulated": true`.
3. Open `/api/metrics`; expect `metrics`, `thresholds`, `services`, `alerts`, and `logs`.
4. Load the dashboard; the cards, graph, service table, and logs should populate.
5. Click **Refresh**; the update time and simulated sample should change.
6. Click **Add demo event**; a new INFO/WARN/ERROR event should appear.
7. Resize the browser to test the responsive layout.
8. Threshold alerts appear only when generated demo metrics cross their configured thresholds; the degraded Worker Queue example is present by default.

## Limitations and next steps

- This is a demonstration, not a production observability platform.
- Metric values and service states are simulated; they must not be used for operational decisions.
- Production use would require authenticated cloud/provider integrations, real host exporters/agents, persistent storage, authorization, alert delivery channels, rate limiting, and deployment hardening.
- The chart uses the browser Canvas API and does not require a charting library.

## Academic deliverables

See [`PROJECT_REPORT.md`](PROJECT_REPORT.md) for the abstract, objectives, methodology, modules, testing, conclusion, and viva questions. See [`ARCHITECTURE.md`](ARCHITECTURE.md) for the system architecture.
